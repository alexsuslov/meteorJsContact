if (!Accounts.google) {
  Accounts.google = {};
}

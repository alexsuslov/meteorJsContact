var self;

self = this;

/*

  text     :  String
  chat     :  id
*/


this.chats = new Meteor.Collection('chats');

this.msgs = new Meteor.Collection('msgs');

this.msgs.allow({
  insert: function(userId, doc) {
    return true;
  },
  update: function(userId, docs, fields, modifier) {
    if (docs.owner === userId) {
      return true;
    }
  },
  remove: function(userId, docs) {
    if (docs.owner === userId) {
      return true;
    }
  }
});

this.chats.allow({
  insert: function(userId, doc) {
    return true;
  },
  update: function(userId, docs, fields, modifier) {
    return true;
  },
  remove: function(userId, docs) {
    return false;
  }
});

if (Meteor.isServer) {
  Meteor.publish("msgs", function(chatId) {
    return self.msgs.find({
      chatId: chatId
    });
  });
  Meteor.publish("chats", function() {
    return self.chats.find({
      owner: this.userId
    });
  });
}

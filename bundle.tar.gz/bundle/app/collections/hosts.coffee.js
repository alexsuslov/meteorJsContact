var self;

self = this;

/*

  host     :  String
  hash     :  String
  css      :  string
*/


this.hosts = new Meteor.Collection('hosts');

this.hosts.allow({
  insert: function(userId, doc) {
    return true;
  },
  update: function(userId, docs, fields, modifier) {
    if (docs.owner === userId) {
      return true;
    }
  },
  remove: function(userId, docs) {
    if (docs.owner === userId) {
      return true;
    }
  }
});

if (Meteor.isServer) {
  Meteor.publish("hosts", function() {
    return self.hosts.find();
  });
}
